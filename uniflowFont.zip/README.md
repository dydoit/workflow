# vue-project

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Lints and fixes files
```
npm run lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
### 统一目录命名
1, 文件夹统一用 '-' 连接
2，组件名统一用驼峰命名
3，调用接口的方法统一放在api文件夹下，做好注释
