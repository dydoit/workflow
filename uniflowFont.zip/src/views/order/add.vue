<template>
    <div>
        新增订单
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style lang="scss" scoped>

</style>