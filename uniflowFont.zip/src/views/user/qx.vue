<template>
    <div>
        权限控制
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style lang="scss" scoped>

</style>